document.getElementById("q").value="牛肉";
document.getElementsByClassName("btn-search tb-bg")[0].click();
document.getElementsByClassName("pic-link J_ClickStat J_ItemPicA")[0].click()
document.getElementsByClassName("tm-ind-item tm-ind-reviewCount canClick tm-line3")[0].click()